import { useState, useEffect } from 'react';
import { 
  MapPin, Calendar, Compass, DollarSign, Utensils, Zap, 
  Download, Printer, Loader2, Settings, Check, 
  Map as MapIcon, Clock, Info, Umbrella, X, Heart
} from 'lucide-react';
import { GoogleGenerativeAI } from "@google/generative-ai";
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for Leaflet default icon issues in React
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';
let DefaultIcon = L.icon({
    iconUrl: markerIcon,
    shadowUrl: markerShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

// --- Constants & Prompts ---
const SYSTEM_PROMPT = `You are a professional luxury travel planner. Create a detailed, day-by-day itinerary for a trip.
Return ONLY a strictly valid JSON object. No extra text, no markdown formatting.
Structure:
{
  "destination": "string",
  "totalDays": number,
  "travelStyle": ["string"],
  "summary": "A 1-2 sentence cinematic summary of the trip",
  "itinerary": [
    {
      "day": number,
      "theme": "string",
      "activities": [
        {
          "time": "string",
          "activity": "string",
          "description": "detailed overview",
          "rating": number (1-5),
          "review": "short expert tip or recent visitor review snippet",
          "lat": number,
          "lng": number
        }
      ]
    }
  ]
}`;

const LOADING_STEPS = [
  "Calibrating neural pathways...",
  "Scanning global satellite feeds...",
  "Synthesizing local cultural nodes...",
  "Optimizing travel trajectories...",
  "Filtering hidden stellar gems...",
  "Finalizing your gravity-defying plan..."
];

// --- Helper Functions ---
const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));


const getCleanErrorMessage = (err) => {
  const msg = err.message || "";
  if (msg.includes('429')) {
    return "🚀 Cosmic Traffic Jam! You've reached the Gemini API rate limit (Free Tier). Please wait 60 seconds or switch to Demo Mode.";
  }
  if (msg.includes('API_KEY_INVALID') || msg.includes('403')) {
    return "🔑 Access Denied. Your API key seems invalid. Please update it in Settings.";
  }
  if (msg.includes('SAFETY')) {
    return "🛡️ Safety Check: The AI cannot process this request. Try a different destination or style.";
  }
  if (msg.includes('quota') || msg.includes('limit')) {
    return "📊 Quota reached! You've used up your free requests for now.";
  }
  return "☄️ Transmission Interrupted: " + msg.split(':')[0];
};

const getDemoCoordinates = (dest) => {
  const d = dest.toLowerCase();
  if (d.includes('london')) return [51.5074, -0.1278];
  if (d.includes('paris')) return [48.8566, 2.3522];
  if (d.includes('new york')) return [40.7128, -74.0060];
  if (d.includes('tokyo')) return [35.6762, 139.6503];
  if (d.includes('kyoto')) return [35.0116, 135.7681];
  if (d.includes('rome')) return [41.9028, 12.4964];
  if (d.includes('dubai')) return [25.2048, 55.2708];
  if (d.includes('mumbai')) return [19.0760, 72.8777];
  if (d.includes('delhi')) return [28.6139, 77.2090];
  if (d.includes('sydney')) return [-33.8688, 151.2093];
  if (d.includes('berlin')) return [52.5200, 13.4050];
  if (d.includes('singapore')) return [1.3521, 103.8198];
  return [35.6762, 139.6503]; // Default
};

function MapRecenter({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center && center[0] && center[1]) {
      map.setView(center, 13);
    }
  }, [center, map]);
  return null;
}

// --- Real Geocoding API (Nominatim) ---
const geocodeLocation = async (query) => {
  try {
    const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`);
    const data = await response.json();
    if (data && data.length > 0) {
      return [parseFloat(data[0].lat), parseFloat(data[0].lon)];
    }
    return null;
  } catch (err) {
    console.error("Geocoding failed:", err);
    return null;
  }
};

const MAP_STYLES = {
  satellite: {
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attr: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
  },
  voyager: {
    url: "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",
    attr: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
  },
  osm: {
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attr: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
  },
  dark: {
    url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
    attr: '&copy; <a href="https://carto.com/attributions">CARTO</a>'
  }
};

function App() {
  const [destination, setDestination] = useState('');
  const [days, setDays] = useState(3);
  const [styles, setStyles] = useState([]);
  const DEFAULT_KEY = 'AIzaSyAtlWyYbXPRY69IIs-tFWeBEo9jfisr07s';
  const [apiKey, setApiKey] = useState(() => {
    const saved = localStorage.getItem('gemini_api_key');
    // If we have a saved key, use it. 
    // BUT if the developer changed the hardcoded DEFAULT_KEY in the source code, 
    // we want that change to reflect for new users or if the saved key is the old default.
    return saved || DEFAULT_KEY;
  });

  // Sync if DEFAULT_KEY changed in source
  useEffect(() => {
    const lastDefault = localStorage.getItem('last_default_key');
    if (DEFAULT_KEY !== lastDefault) {
      localStorage.setItem('gemini_api_key', DEFAULT_KEY);
      localStorage.setItem('last_default_key', DEFAULT_KEY);
      setApiKey(DEFAULT_KEY);
    }

    // Migration to Satellite Map
    if (!localStorage.getItem('map_migrated_satellite')) {
      localStorage.setItem('map_style', 'satellite');
      localStorage.setItem('map_migrated_satellite', 'true');
      setMapStyle('satellite');
    }
  }, []);

  const [useDemo, setUseDemo] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  
  console.log("App Rendering, apiKey present:", !!apiKey);
  
  const [stage, setStage] = useState('search'); // 'search', 'discover', 'results'
  const [suggestions, setSuggestions] = useState([]);
  const [wishlist, setWishlist] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [loadingText, setLoadingText] = useState(LOADING_STEPS[0]);
  const [error, setError] = useState(null);
  const [itinerary, setItinerary] = useState(null);
  const [expandedDescriptions, setExpandedDescriptions] = useState(new Set());
  const [aiStatus, setAiStatus] = useState('healthy'); // 'healthy', 'throttled'
  const [mapStyle, setMapStyle] = useState(() => localStorage.getItem('map_style') || 'satellite');

  const reconnectAI = () => {
    setAiStatus('healthy');
    setUseDemo(false);
    setError(null);
  };

  const toggleExpand = (e, name) => {
    e.stopPropagation();
    setExpandedDescriptions(prev => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  };

  // Auto-save API Key
  useEffect(() => {
    if (apiKey) {
      localStorage.setItem('gemini_api_key', apiKey);
    }
    localStorage.setItem('map_style', mapStyle);
  }, [apiKey, mapStyle]);

  // Loading Simulation
  useEffect(() => {
    let interval;
    if (isLoading) {
      interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 95) return prev;
          const next = prev + Math.random() * 5;
          const stepIndex = Math.floor((next / 100) * LOADING_STEPS.length);
          setLoadingText(LOADING_STEPS[stepIndex] || LOADING_STEPS[LOADING_STEPS.length - 1]);
          return next;
        });
      }, 500);
    }
    return () => clearInterval(interval);
  }, [isLoading, progress]);

  const toggleStyle = (id) => {
    setStyles(prev => prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]);
  };

  const toggleWishlist = (place) => {
    setWishlist(prev => 
      prev.find(p => p.name === place.name) 
        ? prev.filter(p => p.name !== place.name) 
        : [...prev, place]
    );
  };

  const startDiscovery = async (e) => {
    e.preventDefault();
    if (!apiKey && !useDemo) {
      setError("Please add your Gemini API Key in settings first.");
      setShowSettings(true);
      return;
    }
    if (!destination) {
      setError("Please enter a destination first (e.g. 'Paris').");
      return;
    }

    setIsLoading(true);
    setError(null);
    setStage('discover');
    setProgress(5);

    // Get real coordinates for the destination center
    const realCoords = await geocodeLocation(destination);
    const centerCoords = realCoords || getDemoCoordinates(destination);

    try {
      if (useDemo) {
        await wait(1500);
        const [lat, lng] = centerCoords;
        setSuggestions([
          { name: `${destination} Grand Plaza`, type: "Landmark", rating: 4.8, review: "The energy here is unmatched. A must-see at sunset!", description: `The historic heart of ${destination}, surrounded by stunning architecture and local life.`, lat: lat, lng: lng },
          { name: "Skyline Observation Deck", type: "Landmark", rating: 4.9, review: "Clear views for miles. Buy tickets in advance to skip the line.", description: "Panoramic 360-degree views of the entire city and surrounding landscape.", lat: lat + 0.005, lng: lng + 0.008 },
          { name: "The Heritage Museum", type: "Landmark", rating: 4.7, review: "The artifacts are well-preserved and the audio guide is excellent.", description: "A world-class museum showcasing the deep cultural roots of this region.", lat: lat - 0.008, lng: lng + 0.005 },
          { name: "Emerald Botanical Gardens", type: "Landmark", rating: 4.6, review: "A peaceful escape from the city noise. The orchid room is stunning.", description: "A peaceful oasis featuring rare exotic plants and serene walking paths.", lat: lat + 0.012, lng: lng - 0.005 },
          { name: "Crystal Cascades", type: "Landmark", rating: 4.8, review: "Refreshing dip! The water is cold but crystal clear.", description: "A hidden waterfall and series of pools perfect for a refreshing dip or photo.", lat: lat + 0.02, lng: lng + 0.01 },
          { name: "Ancient Observatory", type: "Landmark", rating: 4.5, review: "Great for kids and amateur astronomers alike.", description: "A centuries-old site where travelers can gaze at the stars with vintage equipment.", lat: lat - 0.015, lng: lng - 0.02 },
          { name: "Neon District", type: "Landmark", rating: 4.4, review: "Perfect for street photography. High energy!", description: "A high-energy neighborhood filled with street performers and vibrant lights.", lat: lat + 0.005, lng: lng - 0.025 },
          { name: "Whispering Woods", type: "Landmark", rating: 4.7, review: "Truly magical atmosphere. Bring good walking shoes.", description: "A mystical forest area known for its unique acoustics and ancient trees.", lat: lat - 0.02, lng: lng + 0.015 },
          { name: "Shadow Peak Viewpoint", type: "Landmark", rating: 4.9, review: "Best sunset spot in the city. Arrive 30 mins early.", description: "The highest point in the city, offering dramatic sunset views.", lat: lat + 0.025, lng: lng - 0.01 },
          { name: "The Artisan Alley", type: "Landmark", rating: 4.6, review: "Found some unique handmade souvenirs here.", description: "A narrow street lined with local craft shops and live workshops.", lat: lat - 0.005, lng: lng + 0.025 },
          { name: "Old Clock Tower", type: "Landmark", rating: 4.3, review: "The climb is steep but the mechanical gears are fascinating.", description: "A functioning 18th-century clock tower with a small museum inside.", lat: lat + 0.01, lng: lng + 0.03 },
          { name: "Sunken Cathedral", type: "Landmark", rating: 4.8, review: "Incredibly atmospheric. A silent, holy place.", description: "A partially submerged ruins site with incredible spiritual energy.", lat: lat - 0.03, lng: lng - 0.005 },
          { name: "Infinity Bridge", type: "Landmark", rating: 4.7, review: "Looks like something out of a sci-fi movie at night.", description: "A modern architectural marvel that glows neon blue at night.", lat: lat + 0.015, lng: lng + 0.04 },
          { name: "Marble Promenade", type: "Landmark", rating: 4.5, review: "Great for people watching and morning runs.", description: "A stunning seaside walkway made entirely of polished white stone.", lat: lat - 0.025, lng: lng + 0.03 },
          { name: "The Hanging Gardens", type: "Landmark", rating: 4.6, review: "An engineering masterpiece. Very Instagrammable.", description: "Vertical gardens suspended between two skyscrapers.", lat: lat + 0.035, lng: lng - 0.02 },
          { name: "Echo Canyon", type: "Landmark", rating: 4.4, review: "Shout your name and wait for it! Fun for everyone.", description: "A natural formation where whispers can be heard from miles away.", lat: lat - 0.04, lng: lng + 0.01 },
          { name: "Iron Gate Fortress", type: "Landmark", rating: 4.7, review: "Deep historical roots. The guided tour is worth every penny.", description: "A medieval stronghold with cannons, secret passages, and guided tours.", lat: lat + 0.04, lng: lng + 0.02 },
          { name: "Velvet Valley", type: "Landmark", rating: 4.5, review: "The moss feels like carpet. So relaxing.", description: "Soft, mossy hills that are perfect for a quiet afternoon picnic.", lat: lat - 0.02, lng: lng - 0.04 },
          { name: "The Glass Pier", type: "Landmark", rating: 4.8, review: "Felt like walking on water. Spotted some dolphins!", description: "A transparent walkway over the ocean where you can see marine life below.", lat: lat + 0.05, lng: lng + 0.01 },
          { name: "Golden Gate Archway", type: "Landmark", rating: 4.6, review: "Grand entrance to the old city. Truly impressive scale.", description: "A massive gilded arch that marks the entrance to the historic district.", lat: lat - 0.01, lng: lng + 0.05 },
          { name: "Starlight Boutique Hotel (5★)", type: "Hotel", rating: 5.0, review: "The service is impeccable. Best stay of my life.", description: "A chic, luxury 5-star stay with curated art and personalized service.", lat: lat + 0.015, lng: lng - 0.01 },
          { name: "The Royal Residence (4★)", type: "Hotel", rating: 4.8, review: "Authentic historic feel with modern comforts.", description: "Experience royal treatment in this restored 4-star palace-turned-hotel.", lat: lat - 0.015, lng: lng + 0.012 },
          { name: "Cloud Nine Suites (5★)", type: "Hotel", rating: 4.9, review: "The view from the bathtub was worth the price alone.", description: "Ultra-modern 5-star rooms with floor-to-ceiling glass in the highest tower.", lat: lat + 0.045, lng: lng + 0.02 },
          { name: "Vintage Villa (3★)", type: "Hotel", rating: 4.2, review: "Cozy and quiet. Perfect for a long-term stay.", description: "A charming 3-star colonial-style house with lush private courtyards.", lat: lat - 0.035, lng: lng - 0.03 },
          { name: "Metropolitan Plaza (4★)", type: "Hotel", rating: 4.5, review: "Right in the action. The rooftop pool is great.", description: "A central 4-star hub with a rooftop pool and world-class spa.", lat: lat + 0.01, lng: lng - 0.04 },
          { name: "Serene Sands Resort (5★)", type: "Hotel", rating: 4.9, review: "Paradise on earth. The private beach is secluded.", description: "Premium 5-star beachfront villas with private infinity pools.", lat: lat - 0.05, lng: lng + 0.02 },
          { name: "Gourmet Garden Bistro", type: "Restaurant", rating: 4.7, review: "The farm-to-table menu is fresh and creative.", description: "Exquisite local delicacies served in a stunning, lush garden setting.", lat: lat - 0.01, lng: lng - 0.01 },
          { name: "Old Harbor Grill", type: "Restaurant", rating: 4.6, review: "Freshest seafood I've ever had. Try the daily catch.", description: "The best fresh catch of the day, prepared with traditional secret recipes.", lat: lat + 0.01, lng: lng + 0.015 },
          { name: "The Neon Noodle Bar", type: "Restaurant", rating: 4.4, review: "Fast, loud, and delicious. Get the spicy ramen.", description: "A vibrant, modern take on classic street food favorites.", lat: lat - 0.005, lng: lng + 0.045 },
          { name: "Summit Tea House", type: "Restaurant", rating: 4.8, review: "Incredibly peaceful. The matcha is high grade.", description: "Traditional tea ceremony with sweeping views of the valley.", lat: lat + 0.05, lng: lng - 0.035 },
          { name: "Midnight Diner", type: "Restaurant", rating: 4.3, review: "Exactly what you want at 2 AM. Reliable and fast.", description: "A classic 24/7 spot for comfort food and city vibes.", lat: lat + 0.02, lng: lng - 0.05 },
          { name: "Celestial Cafe", type: "Restaurant", rating: 4.7, review: "The pancakes are fluffy and the view is unmatched.", description: "Breakfast with a view of the morning fog lifting from the city.", lat: lat - 0.01, lng: lng + 0.06 }
        ]);
        setProgress(100);
        return;
      }

      const trimmedKey = apiKey.trim();
      const genAI = new GoogleGenerativeAI(trimmedKey);
      const modelsToTry = [
        "gemini-2.0-flash", 
        "gemini-1.5-flash", 
        "gemini-1.5-pro"
      ];
      let text = "";

      const delay = (ms) => new Promise(res => setTimeout(res, ms));

      for (const modelName of modelsToTry) {
        try {
          console.log(`Discovery attempt with ${modelName}...`);
          setLoadingText(`Contacting ${modelName.split('/')[1]}...`);
          
          const model = genAI.getGenerativeModel({ model: modelName });
          const prompt = `Provide a comprehensive and extensive catalog of top-rated places in ${destination} for a traveler who selected these styles: ${styles.join(', ') || 'General Sightseeing'}. 
          
          GUIDELINES:
          - Provide a massive list of Landmarks and Attractions (Famous sites, hidden gems, parks, cultural hubs, viewpoints).
          - Provide a broad selection of Hotels and Stays (specifically 3-stars or higher).
          - Include a rich variety of Restaurants and Cafes.
          - DO NOT limit the result count to a small number; give as many relevant results as the context window allows for a high-density discovery experience.
          
          Return ONLY a JSON array of objects: [{"name": "string", "type": "Hotel|Landmark|Restaurant", "description": "extensive detailed overview", "review": "a short expert tip or recent visitor review snippet", "rating": number, "lat": number, "lng": number}]. No markdown.`;

          const result = await model.generateContent(prompt);
          const response = await result.response;
          text = response.text();
          if (text) break;
        } catch (err) {
          console.warn(`Discovery model ${modelName} failed:`, err);
          
          // If it's a rate limit, wait 2 seconds before trying the next model
          if (err.message?.includes('429')) {
            console.log("Rate limit hit, waiting 2s...");
            await delay(2000);
          }
          
          if (err.message?.includes('API_KEY_INVALID') || err.message?.includes('403')) break;
        }
      }

      if (!text) {
        console.warn("All models failed. Falling back to Demo Mode.");
        setAiStatus('throttled');
        setUseDemo(true);
        const [lat, lng] = centerCoords;
        setSuggestions([
          { name: `${destination} Grand Plaza`, type: "Landmark", description: `The historic heart of ${destination}, surrounded by stunning architecture and local life.`, lat: lat, lng: lng },
          { name: "Skyline Observation Deck", type: "Landmark", description: "Panoramic 360-degree views of the entire city and surrounding landscape.", lat: lat + 0.005, lng: lng + 0.008 },
          { name: "The Heritage Museum", type: "Landmark", description: "A world-class museum showcasing the deep cultural roots of this region.", lat: lat - 0.008, lng: lng + 0.005 },
          { name: "Emerald Botanical Gardens", type: "Landmark", description: "A peaceful oasis featuring rare exotic plants and serene walking paths.", lat: lat + 0.012, lng: lng - 0.005 },
          { name: "Crystal Cascades", type: "Landmark", description: "A hidden waterfall and series of pools perfect for a refreshing dip or photo.", lat: lat + 0.02, lng: lng + 0.01 },
          { name: "Ancient Observatory", type: "Landmark", description: "A centuries-old site where travelers can gaze at the stars with vintage equipment.", lat: lat - 0.015, lng: lng - 0.02 },
          { name: "Neon District", type: "Landmark", description: "A high-energy neighborhood filled with street performers and vibrant lights.", lat: lat + 0.005, lng: lng - 0.025 },
          { name: "Whispering Woods", type: "Landmark", description: "A mystical forest area known for its unique acoustics and ancient trees.", lat: lat - 0.02, lng: lng + 0.015 },
          { name: "Shadow Peak Viewpoint", type: "Landmark", description: "The highest point in the city, offering dramatic sunset views.", lat: lat + 0.025, lng: lng - 0.01 },
          { name: "The Artisan Alley", type: "Landmark", description: "A narrow street lined with local craft shops and live workshops.", lat: lat - 0.005, lng: lng + 0.025 },
          { name: "Old Clock Tower", type: "Landmark", description: "A functioning 18th-century clock tower with a small museum inside.", lat: lat + 0.01, lng: lng + 0.03 },
          { name: "Sunken Cathedral", type: "Landmark", description: "A partially submerged ruins site with incredible spiritual energy.", lat: lat - 0.03, lng: lng - 0.005 },
          { name: "Infinity Bridge", type: "Landmark", description: "A modern architectural marvel that glows neon blue at night.", lat: lat + 0.015, lng: lng + 0.04 },
          { name: "Marble Promenade", type: "Landmark", description: "A stunning seaside walkway made entirely of polished white stone.", lat: lat - 0.025, lng: lng + 0.03 },
          { name: "The Hanging Gardens", type: "Landmark", description: "Vertical gardens suspended between two skyscrapers.", lat: lat + 0.035, lng: lng - 0.02 },
          { name: "Echo Canyon", type: "Landmark", description: "A natural formation where whispers can be heard from miles away.", lat: lat - 0.04, lng: lng + 0.01 },
          { name: "Starlight Boutique Hotel", type: "Hotel", description: "A chic, luxury stay with curated art and personalized service.", lat: lat + 0.015, lng: lng - 0.01 },
          { name: "The Royal Residence", type: "Hotel", description: "Experience royal treatment in this restored palace-turned-hotel.", lat: lat - 0.015, lng: lng + 0.012 },
          { name: "Cloud Nine Suites", type: "Hotel", description: "Ultra-modern rooms with floor-to-ceiling glass in the highest tower.", lat: lat + 0.045, lng: lng + 0.02 },
          { name: "Vintage Villa", type: "Hotel", description: "A charming colonial-style house with lush private courtyards.", lat: lat - 0.035, lng: lng - 0.03 },
          { name: "Gourmet Garden Bistro", type: "Restaurant", description: "Exquisite local delicacies served in a stunning, lush garden setting.", lat: lat - 0.01, lng: lng - 0.01 },
          { name: "Old Harbor Grill", type: "Restaurant", description: "The best fresh catch of the day, prepared with traditional secret recipes.", lat: lat + 0.01, lng: lng + 0.015 },
          { name: "The Neon Noodle Bar", type: "Restaurant", description: "A vibrant, modern take on classic street food favorites.", lat: lat - 0.005, lng: lng + 0.045 },
          { name: "Summit Tea House", type: "Restaurant", description: "Traditional tea ceremony with sweeping views of the valley.", lat: lat + 0.05, lng: lng - 0.035 }
        ]);
        setProgress(100);
        return;
      }

      const jsonMatch = text.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        setSuggestions(JSON.parse(jsonMatch[0]));
      }
      setProgress(100);
    } catch (err) {
      console.error("Discovery Error:", err);
      setError(getCleanErrorMessage(err));
      setStage('search');
    } finally {
      setIsLoading(false);
      setProgress(0);
    }
  };

  const generateItinerary = async () => {
    setIsLoading(true);
    setError(null);
    setProgress(10);
    setStage('results');

    try {
      if (useDemo) {
        await wait(2000);
        const demoData = {
          destination: destination || "Paris, France",
          totalDays: days,
          travelStyle: styles.length ? styles : ["General"],
          summary: `A breathtaking ${days}-day journey through the heart of ${destination || "the world"}, including your favorites like ${wishlist.map(p => p.name).join(', ') || 'hidden local gems'}.`,
          itinerary: Array.from({ length: days }).map((_, i) => ({
            day: i + 1,
            theme: "Personalized Discovery",
            activities: [
              { 
                time: "10:00 AM", 
                activity: wishlist[i % wishlist.length]?.name || "Local Exploration", 
                description: wishlist[i % wishlist.length]?.description || "Discovering the beauty of the city.",
                lat: wishlist[i % wishlist.length]?.lat || 0,
                lng: wishlist[i % wishlist.length]?.lng || 0
              },
              { 
                time: "01:00 PM", 
                activity: "Gastronomy Experience", 
                description: "Lunch at a curated spot near your previous activity.",
                lat: (wishlist[i % wishlist.length]?.lat || 0) + 0.005,
                lng: (wishlist[i % wishlist.length]?.lng || 0) - 0.005
              },
              { 
                time: "04:00 PM", 
                activity: "Leisurely Walk", 
                description: "Explore the surrounding neighborhoods at your own pace.",
                lat: (wishlist[i % wishlist.length]?.lat || 0) - 0.005,
                lng: (wishlist[i % wishlist.length]?.lng || 0) + 0.005
              }
            ]
          }))
        };
        setItinerary(demoData);
        setProgress(100);
        await wait(500);
        setProgress(0);
        return;
      }

      const trimmedKey = apiKey.trim();
      const genAI = new GoogleGenerativeAI(trimmedKey);
      const modelsToTry = [
        "gemini-2.0-flash", 
        "gemini-1.5-flash", 
        "gemini-1.5-pro"
      ];
      let errorMessages = [];
      let responseText = "";

      const delay = (ms) => new Promise(res => setTimeout(res, ms));

      const wishlistNames = wishlist.map(p => p.name).join(', ');
      const prompt = `Create a ${days}-day itinerary for ${destination} for a traveler who likes ${styles.join(', ') || 'general sightseeing'}. 
      CRITICAL: You MUST include these specific places in the plan: ${wishlistNames}.
      ${SYSTEM_PROMPT}`;

      for (const modelName of modelsToTry) {
        try {
          console.log(`Attempting generation with ${modelName}...`);
          setLoadingText(`Crafting with ${modelName.split('/')[1]}...`);
          
          const model = genAI.getGenerativeModel({ model: modelName });
          const result = await model.generateContent(prompt);
          const response = await result.response;
          responseText = response.text();
          
          if (responseText) {
            console.log(`Successfully generated with ${modelName}`);
            break;
          }
        } catch (err) {
          console.error(`Model ${modelName} failed:`, err);
          errorMessages.push(`${modelName}: ${err.message || 'Unknown error'}`);
          
          if (err.message?.includes('429')) {
            console.log("Rate limit hit, waiting 2s...");
            await delay(2000);
          }
          
          if (err.message?.includes('API_KEY_INVALID') || err.message?.includes('403')) {
            throw err;
          }
        }
      }

      if (!responseText) {
        console.warn("Itinerary generation failed. Falling back to Demo Mode.");
        setAiStatus('throttled');
        setUseDemo(true);
        // We'll let the next block handle the demo data by returning early and calling with useDemo=true
        // or just fulfill it here to be faster.
        const demoData = {
          destination: destination || "Global Destination",
          totalDays: days,
          travelStyle: styles.length ? styles : ["General"],
          summary: `A breathtaking ${days}-day journey through the heart of ${destination || "the world"}, specially curated for your preferences.`,
          itinerary: Array.from({ length: days }).map((_, i) => ({
            day: i + 1,
            theme: "Personalized Discovery",
            activities: [
              { 
                time: "10:00 AM", 
                activity: wishlist[i % wishlist.length]?.name || "Local Exploration", 
                description: wishlist[i % wishlist.length]?.description || "Discovering the beauty of the city.",
                lat: wishlist[i % wishlist.length]?.lat || 0,
                lng: wishlist[i % wishlist.length]?.lng || 0
              },
              { 
                time: "01:00 PM", 
                activity: "Gastronomy Experience", 
                description: "Lunch at a curated spot near your previous activity.",
                lat: (wishlist[i % wishlist.length]?.lat || 0) + 0.005,
                lng: (wishlist[i % wishlist.length]?.lng || 0) - 0.005
              },
              { 
                time: "04:00 PM", 
                activity: "Leisurely Walk", 
                description: "Explore the surrounding neighborhoods at your own pace.",
                lat: (wishlist[i % wishlist.length]?.lat || 0) - 0.005,
                lng: (wishlist[i % wishlist.length]?.lng || 0) + 0.005
              }
            ]
          }))
        };
        setItinerary(demoData);
        setProgress(100);
        return;
      }
      
      let cleanJson = responseText;
      
      // Robust JSON extraction
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        cleanJson = jsonMatch[0];
      }
      
      try {
        const data = JSON.parse(cleanJson);
        setItinerary(data);
      } catch (parseErr) {
        console.error("JSON Parse Error. Cleaned string:", cleanJson);
        throw new Error("The AI returned an unexpected format. Please try one more time.", { cause: parseErr });
      }
      
      setProgress(100);
    } catch (err) {
      console.error("Itinerary Error:", err);
      setError(getCleanErrorMessage(err));
    } finally {
      setIsLoading(false);
      setProgress(0);
    }
  };

  const handlePrint = () => window.print();

  const handleDownload = () => {
    if (!itinerary) return;
    const content = `ITINERARY: ${itinerary.destination.toUpperCase()}\n` +
      `Duration: ${itinerary.totalDays} Days\n` +
      `Styles: ${itinerary.travelStyle.join(', ')}\n\n` +
      itinerary.itinerary.map(day => (
        `DAY ${day.day}: ${day.theme}\n` +
        day.activities.map(a => `- ${a.time}: ${a.activity}\n  ${a.description}`).join('\n')
      )).join('\n\n');

    const element = document.createElement("a");
    const file = new Blob([content], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `${itinerary.destination}_itinerary.txt`;
    document.body.appendChild(element);
    element.click();
  };

  return (
    <div className="app-container">
      <div className="status-container animate-fade-in">
        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
          <div className={`status-pill ${aiStatus}`}>
            <Zap size={14} fill={aiStatus === 'healthy' ? "currentColor" : "none"} />
            {aiStatus === 'healthy' ? 'AI Online' : 'AI Quota Reached'}
          </div>
          <button className="settings-trigger glass" onClick={() => setShowSettings(true)} title="Settings">
            <Settings size={18} />
          </button>
        </div>
        {useDemo && (
          <button className="glass reconnect-btn" onClick={reconnectAI}>
            Try Reconnect
          </button>
        )}
      </div>
      {/* Sky Background Elements */}
      <div className="sky-background">
        <div className="cloud" style={{ top: '10%', left: '10%', animationDelay: '0s' }}></div>
        <div className="cloud" style={{ top: '30%', left: '40%', animationDelay: '5s' }}></div>
        <div className="cloud" style={{ top: '15%', left: '70%', animationDelay: '10s' }}></div>
        <div className="plane">✈️</div>
        <div className="train"></div>
      </div>
      {/* Settings Modal */}
      {showSettings && (
        <div className="glass animate-fade-in" style={{
          position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
          zIndex: 100, padding: '2rem', width: '90%', maxWidth: '400px'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
            <h3 style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Settings size={20} /> Settings
            </h3>
            <button onClick={() => setShowSettings(false)} className="btn-secondary" style={{ padding: '0.2rem 0.5rem' }}><X size={16} /></button>
          </div>
          <div className="input-group">
            <label>Gemini API Key</label>
            <input 
              type="password" 
              placeholder="Paste your key here..."
              value={apiKey}
              onChange={(e) => {
                setApiKey(e.target.value);
                setAiStatus('healthy');
                setUseDemo(false);
                setError(null);
              }}
            />
            <p style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', marginTop: '0.5rem' }}>
              Get yours at <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noreferrer" style={{ color: 'var(--accent-primary)' }}>AI Studio</a>
            </p>
          </div>

          <div className="input-group" style={{ marginTop: '1.5rem' }}>
            <label>Map Visual Style</label>
            <select 
              className="glass"
              style={{ width: '100%', padding: '0.8rem', borderRadius: '12px', background: 'white', border: '2px solid #e2e8f0', color: 'var(--text-primary)', fontSize: '0.9rem' }}
              value={mapStyle}
              onChange={(e) => setMapStyle(e.target.value)}
            >
              <option value="satellite">Satellite View (Esri World Imagery)</option>
              <option value="voyager">Premium (CartoDB Voyager)</option>
              <option value="osm">Standard (OpenStreetMap)</option>
              <option value="dark">Cinematic (CartoDB Dark)</option>
            </select>
            <p style={{ fontSize: '0.7rem', color: 'var(--text-secondary)', marginTop: '0.5rem' }}>
              Switch style if tiles fail to load or hit a limit.
            </p>
          </div>
          <div className="checkbox-item" style={{ marginTop: '1rem', width: '100%', justifyContent: 'space-between' }} onClick={() => setUseDemo(!useDemo)}>
            <span>Enable Demo Mode (No API Key)</span>
            <div style={{ width: '40px', height: '20px', background: useDemo ? 'var(--accent-primary)' : '#333', borderRadius: '10px', position: 'relative', transition: '0.3s' }}>
              <div style={{ width: '16px', height: '16px', background: 'white', borderRadius: '50%', position: 'absolute', top: '2px', left: useDemo ? '22px' : '2px', transition: '0.3s' }}></div>
            </div>
          </div>
          <button className="btn-primary" style={{ marginTop: '1.5rem', width: '100%' }} onClick={() => setShowSettings(false)}>
            Save Configuration
          </button>
        </div>
      )}

      {/* Hero Section - Only show in Search Stage */}
      {stage === 'search' && (
        <header className="hero animate-fade-in">
          <div className="animate-float">
            <h1>Gravity Travel AI</h1>
            <p>Experience the future of travel planning. Bespoke itineraries generated by high-dimensional intelligence.</p>
          </div>
          
          <form onSubmit={startDiscovery} className="glass planner-form">
            <div className="input-group">
              <label>Destination</label>
              <div className="input-wrapper">
                <MapPin size={20} />
                <input 
                  required
                  placeholder="e.g. Kyoto, Japan" 
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                />
              </div>
            </div>
            <div className="input-group">
              <label>Duration (Days)</label>
              <div className="input-wrapper">
                <Calendar size={20} />
                <input 
                  type="number" 
                  min="1" max="14"
                  value={days}
                  onChange={(e) => setDays(e.target.value)}
                />
              </div>
            </div>
            
            <div className="style-grid">
              <div 
                className={`style-card adventure ${styles.includes('Adventure') ? 'active' : ''}`}
                onClick={() => toggleStyle('Adventure')}
              >
                <Compass size={32} />
                <span>Adventure</span>
              </div>
              <div 
                className={`style-card foodie ${styles.includes('Foodie') ? 'active' : ''}`}
                onClick={() => toggleStyle('Foodie')}
              >
                <Utensils size={32} />
                <span>Foodie</span>
              </div>
              <div 
                className={`style-card relax ${styles.includes('Relax') ? 'active' : ''}`}
                onClick={() => toggleStyle('Relax')}
              >
                <Umbrella size={32} />
                <span>Relax</span>
              </div>
              <div 
                className={`style-card budget ${styles.includes('Budget') ? 'active' : ''}`}
                onClick={() => toggleStyle('Budget')}
              >
                <DollarSign size={32} />
                <span>Budget</span>
              </div>
            </div>

            <button type="submit" className="btn-primary" disabled={isLoading}>
              {isLoading ? <Loader2 className="animate-spin" /> : <Compass size={18} />}
              {isLoading ? "Analyzing..." : "Discover Places"}
            </button>

            {isLoading && (
              <div style={{ gridColumn: 'span 2', marginTop: '1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>
                  <span>{loadingText}</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <div className="progress-container">
                  <div className="progress-bar" style={{ width: `${progress}%` }}></div>
                </div>
              </div>
            )}
          </form>

          {error && (
            <div className="glass error-alert animate-fade-in">
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', justifyContent: 'center' }}>
                <Info size={18} /> {error}
              </div>
              {(error.includes('limit') || error.includes('API') || error.includes('Quota') || error.includes('Denied')) && (
                <div style={{ marginTop: '0.75rem', display: 'flex', justifyContent: 'center', gap: '1rem' }}>
                  <button 
                    className="btn-secondary" 
                    style={{ padding: '0.4rem 1rem', fontSize: '0.75rem', borderRadius: '12px' }}
                    onClick={() => { setUseDemo(true); setError(null); }}
                  >
                    🚀 Try Demo Mode
                  </button>
                  <button 
                    className="btn-secondary" 
                    style={{ padding: '0.4rem 1rem', fontSize: '0.75rem', borderRadius: '12px', border: '1px solid var(--accent-primary)', color: 'var(--accent-primary)' }}
                    onClick={() => setShowSettings(true)}
                  >
                    🔑 Update API Key
                  </button>
                </div>
              )}
            </div>
          )}
        </header>
      )}

      {/* Discovery Stage */}
      {stage === 'discover' && (
        <main className="discovery-container animate-fade-in">
          <div className="discovery-header">
            <h2 style={{ fontSize: '2.5rem' }}>Discovery Map: {destination}</h2>
            <p style={{ color: 'var(--text-secondary)' }}>Select pins on the map or cards below to build your wishlist.</p>
          </div>

          <div className="discovery-layout">
            <div className="map-wrapper glass" style={{ height: '600px', position: 'relative' }}>
              {suggestions.length > 0 && suggestions[0].lat ? (
                <MapContainer 
                  center={[suggestions[0].lat, suggestions[0].lng]} 
                  zoom={13} 
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer
                    url={MAP_STYLES[mapStyle]?.url || MAP_STYLES.satellite.url}
                    attribution={MAP_STYLES[mapStyle]?.attr || MAP_STYLES.satellite.attr}
                  />
                  <MapRecenter center={[suggestions[0].lat, suggestions[0].lng]} />
                  {suggestions.map((place, idx) => (
                    <Marker 
                      key={idx} 
                      position={[place.lat, place.lng]}
                      title={place.name}
                    >
                      <Popup minWidth={300}>
                        <div style={{ color: '#000', padding: '1.25rem' }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.5rem' }}>
                            <strong style={{ fontSize: '1.2rem', lineHeight: '1.2' }}>{place.name}</strong>
                            <span style={{ fontSize: '0.65rem', background: 'var(--accent-primary)', color: 'white', padding: '2px 8px', borderRadius: '10px', fontWeight: '700' }}>{place.type}</span>
                          </div>
                          
                          {place.rating && (
                            <div style={{ color: '#f59e0b', marginBottom: '0.75rem', fontSize: '0.9rem' }}>
                              {'★'.repeat(Math.floor(place.rating))}
                              <span style={{ color: '#94a3b8', marginLeft: '0.5rem', fontWeight: '600' }}>{place.rating}/5</span>
                            </div>
                          )}

                          <p style={{ fontSize: '0.9rem', lineHeight: '1.5', color: '#334155', marginBottom: '1rem', fontWeight: '500' }}>{place.description || "Detailed overview coming soon for this stunning destination."}</p>
                          
                          {place.review && (
                            <div style={{ background: '#f8fafc', padding: '0.75rem', borderRadius: '12px', borderLeft: '4px solid var(--accent-primary)', marginBottom: '1.25rem' }}>
                              <p style={{ fontSize: '0.8rem', fontStyle: 'italic', color: '#475569', margin: 0 }}>
                                " {place.review} "
                              </p>
                            </div>
                          )}

                          <button 
                            className={`wishlist-btn ${wishlist.find(p => p.name === place.name) ? 'selected' : ''}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleWishlist(place);
                            }}
                            style={{ width: '100%', justifyContent: 'center', background: wishlist.find(p => p.name === place.name) ? 'var(--success)' : 'var(--accent-primary)', color: 'white', border: 'none', padding: '0.8rem' }}
                          >
                            {wishlist.find(p => p.name === place.name) ? <Check size={16} /> : <Zap size={16} />}
                            {wishlist.find(p => p.name === place.name) ? 'Added to Trip' : 'Add to Trip'}
                          </button>
                        </div>
                      </Popup>
                    </Marker>
                  ))}
                </MapContainer>
              ) : (
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: 'var(--text-secondary)' }}>
                  <Loader2 className="animate-spin" /> Loading Interactive Map...
                </div>
              )}
            </div>

            <div className="discovery-list">
              {suggestions.map((place, idx) => {
                const isSelected = wishlist.find(p => p.name === place.name);
                return (
                  <div key={idx} className={`glass discovery-card ${isSelected ? 'selected' : ''}`} onClick={() => toggleWishlist(place)}>
                    <button className={`wishlist-heart ${isSelected ? 'active' : ''}`}>
                      <Heart size={20} fill={isSelected ? "currentColor" : "none"} />
                    </button>
                    <div className="card-badge" style={{ right: '4rem' }}>{place.type}</div>
                    <h3>{place.name}</h3>
                    
                    {place.rating && (
                      <div style={{ color: '#f59e0b', fontSize: '0.8rem', marginBottom: '0.5rem' }}>
                        {'★'.repeat(Math.floor(place.rating))}
                        <span style={{ color: 'var(--text-secondary)', marginLeft: '0.4rem' }}>{place.rating}</span>
                      </div>
                    )}

                    <p className={`description-text ${expandedDescriptions.has(place.name) ? 'expanded' : ''}`}>
                      {place.description}
                    </p>
                    
                    {place.review && expandedDescriptions.has(place.name) && (
                      <div style={{ marginTop: '0.5rem', padding: '0.5rem', background: 'rgba(14, 165, 233, 0.05)', borderRadius: '8px', borderLeft: '2px solid var(--accent-primary)', fontSize: '0.75rem', fontStyle: 'italic' }}>
                        "{place.review}"
                      </div>
                    )}
                    <button className="see-more-btn" onClick={(e) => toggleExpand(e, place.name)}>
                      {expandedDescriptions.has(place.name) ? 'See Less' : 'See More'}
                    </button>
                    <button className="wishlist-btn">
                      {isSelected ? <Check size={16} /> : <Zap size={16} />}
                      {isSelected ? 'In Wishlist' : 'Add to Trip'}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {wishlist.length > 0 && (
            <div className="wishlist-float glass animate-slide-in">
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <div className="wishlist-count">{wishlist.length}</div>
                <div>
                  <h4 style={{ margin: 0 }}>Selected Gems</h4>
                  <p style={{ margin: 0, fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Ready to craft your journey</p>
                </div>
              </div>
              <button className="btn-primary" onClick={generateItinerary} disabled={isLoading} style={{ gridColumn: 'auto', padding: '0.75rem 2rem' }}>
                {isLoading ? <Loader2 className="animate-spin" /> : "Craft My Journey"}
              </button>
            </div>
          )}

          <div style={{ textAlign: 'center', marginTop: '2rem' }}>
             <button className="btn-back" onClick={() => setStage('search')}>
               <Compass size={20} /> Back to Planner
             </button>
          </div>
        </main>
      )}

      {/* Results Section */}
      {stage === 'results' && itinerary && (
        <main className="results-container animate-fade-in">
          <div className="itinerary-header glass">
            {/* Cinematic Header Image (Using high-quality placeholder to simulate Imagen 4 results) */}
            <img 
              src={`https://images.unsplash.com/featured/?${encodeURIComponent(itinerary.destination)},travel,cinematic`} 
              alt={itinerary.destination} 
              style={{ objectFit: 'cover', width: '100%', height: '100%' }}
              onError={(e) => {
                e.target.src = 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&q=80&w=1600&h=600';
              }}
            />
            <div className="header-content">
              <h2 style={{ fontSize: '3rem', marginBottom: '0.5rem' }}>{itinerary.destination}</h2>
              <p style={{ opacity: 0.9, maxWidth: '600px' }}>{itinerary.summary}</p>
            </div>
          </div>

          <div className="action-bar no-print">
            <button className="btn-secondary" onClick={handleDownload}><Download size={18} /> Download .txt</button>
            <button className="btn-secondary" onClick={handlePrint}><Printer size={18} /> Print Itinerary</button>
            <button className="btn-secondary" onClick={() => setShowSettings(true)}><Settings size={18} /> Settings</button>
          </div>

          <div className="timeline" style={{ marginTop: '3rem' }}>
            {itinerary.itinerary.map((day, idx) => (
              <div key={idx} className="timeline-item animate-slide-in" style={{ animationDelay: `${idx * 0.1}s` }}>
                <div className="glass day-card">
                  <div className="day-header">
                    <h3 style={{ color: 'var(--accent-primary)', fontSize: '1.5rem' }}>Day {day.day}</h3>
                    <span style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', fontWeight: '600' }}>{day.theme}</span>
                  </div>
                  
                  {day.activities.map((activity, aIdx) => (
                    <div key={aIdx} className="activity">
                      <div className="activity-time">
                        <Clock size={14} style={{ marginRight: '4px', verticalAlign: 'middle' }} />
                        {activity.time}
                      </div>
                      <div className="activity-details">
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                          <h4 style={{ marginBottom: '0.25rem' }}>{activity.activity}</h4>
                          {activity.rating && (
                            <span style={{ color: '#f59e0b', fontSize: '0.75rem' }}>{'★'.repeat(Math.floor(activity.rating))}</span>
                          )}
                        </div>
                        <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>{activity.description}</p>
                        {activity.review && (
                          <p style={{ fontSize: '0.8rem', fontStyle: 'italic', color: 'var(--accent-primary)', opacity: 0.8 }}>
                            Tip: {activity.review}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}

                  {/* Real Map View for the Day */}
                  <div className="map-view-real glass" style={{ height: '200px', borderRadius: '12px', overflow: 'hidden', marginTop: '1rem' }}>
                    {day.activities.some(a => a.lat) ? (
                      <MapContainer 
                        center={[day.activities[0].lat, day.activities[0].lng]} 
                        zoom={12} 
                        style={{ height: '100%', width: '100%' }}
                        scrollWheelZoom={false}
                      >
                        <TileLayer
                          url={MAP_STYLES[mapStyle]?.url || MAP_STYLES.satellite.url}
                          attribution={MAP_STYLES[mapStyle]?.attr || MAP_STYLES.satellite.attr}
                        />
                        {day.activities.map((activity, aIdx) => (
                          activity.lat && (
                            <Marker key={aIdx} position={[activity.lat, activity.lng]}>
                              <Popup minWidth={280}>
                                <div style={{ color: '#000', padding: '1rem' }}>
                                  <strong style={{ fontSize: '1.1rem', display: 'block', marginBottom: '0.25rem' }}>{activity.activity}</strong>
                                  
                                  {activity.rating && (
                                    <div style={{ color: '#f59e0b', marginBottom: '0.5rem', fontSize: '0.8rem' }}>
                                      {'★'.repeat(Math.floor(activity.rating))}
                                    </div>
                                  )}

                                  <p style={{ fontSize: '0.85rem', lineHeight: '1.4', color: '#334155', marginBottom: '0.75rem' }}>{activity.description || "Experience the best of the city at this curated location."}</p>
                                  
                                  {activity.review && (
                                    <div style={{ background: '#f1f5f9', padding: '0.5rem', borderRadius: '8px', borderLeft: '3px solid var(--accent-primary)' }}>
                                      <p style={{ fontSize: '0.75rem', fontStyle: 'italic', color: '#475569', margin: 0 }}>
                                        "{activity.review}"
                                      </p>
                                    </div>
                                  )}
                                </div>
                              </Popup>
                            </Marker>
                          )
                        ))}
                      </MapContainer>
                    ) : (
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: 'var(--text-secondary)', fontSize: '0.8rem' }}>
                         <MapIcon size={20} style={{ marginRight: '8px' }} />
                         Interactive map summary for Day {day.day}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </main>
      )}

      {/* Footer */}
      {!itinerary && !isLoading && (
        <footer style={{ textAlign: 'center', marginTop: '4rem', color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
          <p>© 2026 Gravity Travel AI. Powered by Gemini 3.1 Pro.</p>
        </footer>
      )}
    </div>
  );
}

export default App;
